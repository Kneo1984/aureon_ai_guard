#!/bin/bash\npython3 aureon_loader.py
