# AUREON INSTALLATION 🔮\n\n## Start\n\n```bash\npython aureon_loader.py\n```
